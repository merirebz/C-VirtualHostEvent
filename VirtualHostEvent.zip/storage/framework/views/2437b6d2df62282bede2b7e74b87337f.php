<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title></title>
    <Link rel='stylesheet' href="<?php echo e(asset('styles/form.css')); ?>" >
    <!-- <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> -->
    <meta name="viewport" content="width=device-width,
      initial-scale=1.0"/>
    
  </head>
  <body>

  
    <div class="container">
      <h1 class="form-title">The basics Infos:</h1>
      <form method="post" action= "<?php echo e(route('evenement_create')); ?>" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
        <div class="main-user-info">
          <div class="user-input-box">
            <label for="fullName">Event Name</label>
            <input type="text"
                    id="fullName"
                    name="Eventname"
                    required
                    placeholder="Event name"/>
          </div>
          <div class="user-input-box">
            <label for="username">Organisator name:</label>
            <input type="text"
                    id="Organisatorname"
                    name="Organisatorname"
                    placeholder="Enter your name"/>
          </div>
          <div class="user-input-box">
            <label for="date">Starts at:</label>
            <input type="date"
                    id="date"
                    name="dateDebut"
                    />

                    <label for="date">End at:</label>
            <input type="date"
                    id="date"
                    name="dateFin"
                    />
          </div>
            <!-- Time -->


            <div class="user-input-box">
            <label for="heure">Starts at:</label>
            <input type="time"
                    id="heure"
                    name="heureD"
                    />

                    <label for="heure">End at:</label>
            <input type="time"
                    id="heure"
                    name="heureF"
                    />
          </div>

          <div class="user-input-box">
            <label for="image">Image:</label>
            <input type="file"
                    id="image"
                    name="src"
                    placeholder="Choose ...."/>
          </div>
          <!-- <div class="user-input-box">
            <label for="">Payment</label>
            <input type="text"
                    id="payment"
                    name="password"
                    placeholder="Enter Password"/>
          </div> -->
          <!-- <div class="user-input-box">
            <label for="confirmPassword">Confirm Password</label>
            <input type="password"
                    id="confirmPassword"
                    name="confirmPassword"
                    placeholder="Confirm Password"/>
          </div> -->
        </div>
        <div class="gender-details-box">
          <span class="gender-title">Payment</span>
          <div class="gender-category">
            <input type="radio" name="payement" id="free">
            <label for="">Free</label>
            <input type="radio" name="payement" id="paid">
            <label for="">Paid</label>
            <!-- <input type="radio" name="gender" id="other">
            <label for="other">Other</label> -->
          </div>


          <div class="gender-details-box">
          <span class="gender-title">Type</span>
          <div class="gender-category">
            <input type="radio" name="type" id="confer">
            <label for="">Conference</label>
            <input type="radio" name="type" id="webin">
            <label for="">Webinaire</label>
            <input type="radio" name="type" id="train">
            <label for="other">Training</label> 
          </div>
           
          <!-- <div class="user-input-box">
            <label for="">Event type</label>
            <input type="text"
                    id="eventt"
                    name="type"
                    placeholder="Choose type ..."/>
          </div> -->
          <div class="user-input-box">
            <label for="">Event description</label>
            <input type="textarea"
                    id="eventD"
                    name="details"
                    placeholder="Descripe your event"/>
          </div>
          <div class="user-input-box">
            <label for="">Link</label>
            <input type="text"
                    id="link"
                    name="linkEvent"
                    placeholder="Paste link"/>
          </div>

        </div>
        <div class="form-submit-btn">
         <button type="submit">Ajouter</button>
         <a href="<?php echo e(url('cart.blade.php')); ?>">Back</a>
        </div>
      </form>
    </div>
  </body>
  
</html><?php /**PATH C:\xampp\htdocs\VirtualHostEvent\resources\views/formulaire.blade.php ENDPATH**/ ?>