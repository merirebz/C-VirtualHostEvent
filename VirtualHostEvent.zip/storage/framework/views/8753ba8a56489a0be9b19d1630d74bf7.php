<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <Link rel='stylesheet' href="<?php echo e(asset('styles/cart.css')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="main">
<div class="card">
<?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<div class="image">
   <img src="<?php echo e($c->src); ?>">
</div>
<div class="title">
 <h1><?php echo e($c->Eventname); ?></h1>
</div>
<div class="des">
 <p><?php echo e($c->dateDebut); ?></p>
 <p></p>
 <a  type="submit" href="<?php echo e(route('events.read', ['Eventname' => $c->Eventname])); ?>" class="btn btn-primary">Read More...</a>  
</a>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\VirtualHostEvent\resources\views/cart.blade.php ENDPATH**/ ?>