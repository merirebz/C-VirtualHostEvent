<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="<?php echo e(asset('styles/style.css')); ?>" />
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/> 
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php echo $__env->make('nb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <header>
 <h1> Popular Events </h1>  
 </header>

    <section  class="hero-section">

    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <div class="wrapper">  
    
    <div class="card front-face">  
    <img src="<?php echo e(asset('images/'.$c->src)); ?>" alt="" >
    </div>  
    <div class="card back-face">   
     <div class="info">  
      <div class="title"  ><?php echo e($c->Eventname); ?></div>  
       
      <p><br /><?php echo e($c->dateDebut); ?> <?php echo e($c->dateFin); ?></p>  
     </div>  
     <a  type="submit" href='<?php echo e(url("details" ,["Eventname" => $c->Eventname])); ?>' class="btn btn-primary">Read More</a>
     <ul>  
      <a href="#"><i class="fab fa-twitter"></i></a>  
      <a href="#"><i class="fab fa-instagram"></i></a>  
      <a href="#"><i class="fab fa-youtube"></i></a>  
     </ul>  
    </div>  
   </div>  
  
   
   </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </section>

   
        <div class="d-flex justify-content-center mx-auto ">
            <?php echo $cart->links(); ?>

        </div>
  
</body>
</html><?php /**PATH C:\xampp\htdocs\VirtualHostEvent\resources\views/card.blade.php ENDPATH**/ ?>