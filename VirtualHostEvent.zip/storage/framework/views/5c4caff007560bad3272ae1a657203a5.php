<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

        <!-- Styles -->
    </head>
    <body class="antialiased">
      

    <section id="nav" ><?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></section>
    <section id="stiple"><?php echo $__env->make('stiple', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></section>
    <section id="services"><?php echo $__env->make('services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></section>
    <section id="events"><?php echo $__env->make('events', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></section>
    <section id="about"><?php echo $__env->make('About', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></section>
    <section ><?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></section>
            
                
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\VirtualHostEvent\resources\views/welcome.blade.php ENDPATH**/ ?>