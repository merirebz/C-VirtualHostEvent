
<?php $__env->startSection('content'); ?>
  
<div class="card" style="margin:20px;">
  <div class="card-header">Event Page</div>
  <div class="card-body">
        <div class="card-body">
        <h5 class="card-title">Eventname : <?php echo e($events->Eventname); ?></h5>
        <p class="card-text">Organisatorname : <?php echo e($events->Organisatorname); ?></p>
        <p class="card-text">type : <?php echo e($events->type); ?></p>
        <p class="card-text">heureD : <?php echo e($events->heureD); ?></p>
        <p class="card-text">heureF : <?php echo e($events->heureF); ?></p>
        <p class="card-text">dateDebut : <?php echo e($events->dateDebut); ?></p>
        <p class="card-text">dateFin : <?php echo e($events->dateFin); ?></p>
        <p class="card-text">payement : <?php echo e($events->payement); ?></p>
        <p class="card-text">linkEvent : <?php echo e($events->linkEvent); ?></p>
        <p class="card-text">details : <?php echo e($events->details); ?></p>
        <p class="card-text">details : <?php echo e($events->src); ?></p>
       
  </div>
    </hr>
  </div>
</div>
<?php echo $__env->make('events.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VirtualHostEvent\resources\views/events/show.blade.php ENDPATH**/ ?>