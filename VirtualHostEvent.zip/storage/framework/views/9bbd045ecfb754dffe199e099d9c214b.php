<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel='stylesheet' href="<?php echo e(asset('styles/nav.css')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
    <nav class="nav">
      <input type="checkbox" id="check">
      <label for="check" class="checkbtn">
        <i class="fas fa-bars"></i>
      </label>
        <label class="logo">EventVibes</label>
        
            <ul>
                <li><a class="active" href="#stiple">Home</a></li>
                <li><a href="#services">Services</a></li>
                <li><a href="#about">About</a></li>
                <li>
                    <a href="/">
                        <?php if(Route::has('login')): ?>
                            <?php if(auth()->guard()->check()): ?>
                        </a>
                    </li>
                    <!-- <li> <a href="<?php echo e(url('/home')); ?>"
                            class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400
                             dark:hover:text-white focus:outline focus:outline-2 
                             focus:rounded-sm focus:outline-red-500">
                            Profil</a>

                    </li> -->
                    <li>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>"
                            class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Log in</a>
                        <?php if(Route::has('register')): ?>
                    </li>
                    <li> <a href="<?php echo e(url('addU')); ?>"
                            class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Register</a>
                        <?php endif; ?>
                    </li>
                <?php endif; ?>

                <?php endif; ?>
            </ul>

            
    </nav>
    <header></header>
    
</body>

</html>
<?php /**PATH C:\xampp\htdocs\VirtualHostEvent\resources\views/nav.blade.php ENDPATH**/ ?>