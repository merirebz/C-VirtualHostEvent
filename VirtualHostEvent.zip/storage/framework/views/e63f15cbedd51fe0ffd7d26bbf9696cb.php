<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <Link rel="stylesheet" href="<?php echo e(asset('styles/profil.css')); ?>" />  

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
<?php echo $__env->make('nb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <h3 class='title'> Your Profil </h3>   
 
 
 
     <section class="hero-section" >
 
     <?php $__currentLoopData = $profil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
     <div class="wrapper">  
     
     <div class="card front-face">  
     <img src="<?php echo e(asset('images/'.$p->src)); ?>" alt="" width="100">
     </div>  
     <div class="card back-face">   
      <div class="info"  >  
       <div class="title"><?php echo e($p->Eventname); ?></div>  
        
       <p><br /><?php echo e($p->dateDebut); ?> <?php echo e($p->dateFin); ?></p>  
      </div>  
      <a  type="submit" href='<?php echo e(url("details" ,["Eventname" => $p->Eventname])); ?>' class="btn btn-primary">Read More</a>
      <ul>  
       <i class="fab fa-twitter"></i>
       <i class="fab fa-instagram"></i>  
       <i class="fab fa-youtube"></i>  
      </ul>  
     </div>  
    </div>  
   
    
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </section>
    
    
        <div class="d-flex justify-content-center mx-auto ">
            <?php echo $profil->links(); ?>

        </div>

 </body>
</body>
</html><?php /**PATH C:\xampp\htdocs\VirtualHostEvent\resources\views/profilcreator.blade.php ENDPATH**/ ?>