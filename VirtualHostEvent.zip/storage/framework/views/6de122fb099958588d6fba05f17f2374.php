<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <Link rel='stylesheet' href="<?php echo e(asset('styles/about.css')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="ab" >
        
           
                    <div >
                        <h1 class="text-center mt-5 display-3 fw-bold">About Us</h1>
                    <hr class="mx-auto mb-5 w-25" />
                    </div>
                    
                 
                    
                        <div>
                            <h2>One event platform with endless possibilities</h2>
                            <p>Visionary events move from single events to multi-year strategies - intentional programming designed to engage your audience, increase revenue, and raise your profile.
                                EventVibes is the ultimate event technology ecosystem with comprehensive solutions designed to fit any event regardless of size or location.
                                More than just a tech platform, we're your long-term partner, working with you to make every event epic.</p>
                        </div>
                 
                 
                        <div>
                            <img src="<?php echo e(asset('images/our-story-hero.png')); ?>" alt="story" />
                        </div> 
          
        </div>
    

</body>
</html><?php /**PATH C:\xampp\htdocs\VirtualHostEvent\resources\views/about.blade.php ENDPATH**/ ?>