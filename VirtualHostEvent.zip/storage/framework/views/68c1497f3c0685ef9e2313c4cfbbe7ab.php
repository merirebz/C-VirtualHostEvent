<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row" style="margin:20px;">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h2>Laravel 9 CRUD (Create, Read, Update and Delete)</h2>
                    </div>
                    <div class="card-body">
                        <a href="<?php echo e(url('/evenement/create')); ?>"
                         class="btn btn-success btn-sm" title="Add New Event">
                            Add New
                        </a>
                        <br/>
                        <br/>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Eventname</th>
                                        <th>Organisatorname</th>
                                        <th>type</th>
                                        <th>payement</th>
                                        <th>heureD</th>
                                        <th>heureF</th>
                                        <th>dateDebut</th>
                                        <th>dateFin</th>
                                        <th>linkEvent</th>
                                        <th>details</th>
                                        <th>Image</th>

                                      


                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->Eventname); ?></td>
                                        <td><?php echo e($item->Organisatorname); ?></td>
                                        <td><?php echo e($item->type); ?></td>
                                        <td><?php echo e($item->payement); ?></td>
                                        <td><?php echo e($item->heureD); ?></td>
                                        <td><?php echo e($item->heureF); ?></td>
                                        <td><?php echo e($item->dateDebut); ?></td>
                                        <td><?php echo e($item->dateFin); ?></td>
                                        <td><?php echo e($item->linkEvent); ?></td>
                                        <td><?php echo e($item->details); ?></td>
                                        <td><?php echo e($item->src); ?></td>

  
                                        <td>
                             <a href="<?php echo e(url('/evenement/' . $item->idE)); ?>" title="View Event"><button class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i> View</button></a>
                                       <a href="<?php echo e(url('/evenement/' . $item->idE . '/edit')); ?>" title="Edit Event"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>
  
                                            <form method="POST" action="<?php echo e(url('/evenement' . '/' . $item->idE)); ?>" accept-charset="UTF-8" style="display:inline">
                                       <?php echo e(method_field('DELETE')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete Student" onclick="return confirm('Confirm delete?')"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
  
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('events.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VirtualHostEvent\resources\views/events/index.blade.php ENDPATH**/ ?>