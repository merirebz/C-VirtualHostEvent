<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body>

   <section ><?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></section>
    <section><?php echo $__env->make('stiple', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></section>
    <section><?php echo $__env->make('services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></section>
    <section><?php echo $__env->make('about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></section>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\VirtualHostEvent\resources\views/homme.blade.php ENDPATH**/ ?>