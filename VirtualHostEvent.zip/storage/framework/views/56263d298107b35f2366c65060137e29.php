
<?php $__env->startSection('content'); ?>
  
<div class="card" style="margin:20px;">
  <div class="card-header">Edit Event</div>
  <div class="card-body">
       
      <form action="<?php echo e(url('evenement/' .$events->idE)); ?>" method="post">
        <?php echo csrf_field(); ?>

        <?php echo method_field("PATCH"); ?>
        <input type="hidden" name="idE" id="idE" value="<?php echo e($events->idE); ?>" id="idE" />
        <label>Eventname</label></br>
        <input type="text" name="Eventname" id="Eventname" value="<?php echo e($events->Eventname); ?>" class="form-control"></br>
        <label>Organisatorname</label></br>
        <input type="text" name="Organisatorname" id="Organisatorname" value="<?php echo e($events->Organisatorname); ?>" class="form-control"></br>
        <label>heureD</label></br>
        <input type="time" name="heureD" id="heureD" value="<?php echo e($events->heureD); ?>" class="form-control"></br>
        <label>heureF</label></br>
        <input type="time" name="heureF" id="heureF" value="<?php echo e($events->heureF); ?>" class="form-control"></br>
        <label>dateDebut</label></br>
        <input type="date" name="dateDebut" id="dateDebut" value="<?php echo e($events->dateDebut); ?>" class="form-control"></br>
        <label>dateFin</label></br>
        <input type="date" name="dateFin" id="dateFin" value="<?php echo e($events->dateFin); ?>" class="form-control"></br>
        <label>payement</label></br>
        <input type="text" name="payement" id="payement" value="<?php echo e($events->payement); ?>" class="form-control"></br>
        <label>linkeEvent</label></br>
        <input type="url" name="linkeEvent" id="linkeEvent" value="<?php echo e($events->linkeEvent); ?>" class="form-control"></br>
        <label>details</label></br>
        <textarea  name="details" id="details" value="" class="form-control"><?php echo e($events->details); ?></textarea></br>
        <label>type</label></br>
        <input type="text" name="type" id="type" value="<?php echo e($events->type); ?>" class="form-control"></br>
        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>
    
  </div>
</div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('events.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VirtualHostEvent\resources\views/events/edit.blade.php ENDPATH**/ ?>