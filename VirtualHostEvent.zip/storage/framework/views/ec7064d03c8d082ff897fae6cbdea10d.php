<!DOCTYPE html>

<html lang="en">

<head>

    
    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Document</title>

</head>

<body>

    <div class="container">

        <a href="<?php echo e(url('hh/ajouter')); ?>">Ajouter</a>
        <table class="table table-striped">

            <tr>

                <th>Eventname</th>

                <th>DateDebut</th>

                <th>DateFin</th>

                <th>HeureDebut</th>

                <th>HeureFin</th>

                <th>Details</th>

                <th>LinkEvent</th>
                <th>img</th>
                <th>Payement</th>



            </tr>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            
            <tr>

                <td><?php echo e($event->Eventname); ?></td>
                <td><?php echo e($event->dateDebut); ?></td>
                <td><?php echo e($event->dateFin); ?></td>

                <td><?php echo e($event->heureD); ?></td>

                <td><?php echo e($event->heureF); ?></td>

                <td><?php echo e($event->details); ?></td>

                <td><?php echo e($event->linkEvent); ?></td>
                <td>
                    <?php if($event->src): ?>
                   <img src="<?php echo e(asset('images/'.$event->src)); ?>" alt="" width="100">
                   <?php else: ?>
                   Aucune photo
                   <?php endif; ?>
                </td>
                <td><?php echo e($event->payement); ?></td>
                <td>

                    <a href='/modifier/<?php echo e($event->Eventname); ?>'> <button>Update</button></a>





                    
                </td>



                
            </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>

    </div>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\VirtualHostEvent\resources\views/readData.blade.php ENDPATH**/ ?>