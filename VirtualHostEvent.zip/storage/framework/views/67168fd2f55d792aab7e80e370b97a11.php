<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <Link rel='stylesheet' href="<?php echo e(asset('styles/cart.css')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="main">
<div class="card">
<?php $__currentLoopData = $cartt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<div class="image">
   <img src="<?php echo e($t->src); ?>">
</div>
<div class="title">
 <h1><?php echo e($t->Eventname); ?></h1>
</div>
<div class="des">
 <p><?php echo e($t->dateDebut); ?></p>
 <p></p>
 <a  type="submit" href="<?php echo e(route('events.show', ['Eventname' => $t->Eventname])); ?>" class="btn btn-primary">Read More...</a>  
</a>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\VirtualHostEvent\resources\views/cartcreator.blade.php ENDPATH**/ ?>