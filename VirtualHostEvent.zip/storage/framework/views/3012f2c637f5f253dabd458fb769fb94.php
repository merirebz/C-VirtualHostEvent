<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel='stylesheet' href="<?php echo e(asset('styles/cartes.css')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<section >
             
                    
                           
<section class="services-section">
      <div class="inner-width">
        <h1>Our <strong>Services</strong></h1>
        <div class="services owl-carousel">

          <div class="service">
            <div class="service-icon">
            <img src="<?php echo e(('images/regi.png')); ?>"/>
            </div>
            <div class="service-name">Event Registration</div>
            <div class="service-desc">Easily accept registration and payment in advance, 
                                  making signing up a seamless experience for your attendee</div>
          </div>

          <div class="service">
            <div class="service-icon">
              <img src="<?php echo e(('images/tech1.png')); ?>"/>
            </div>
            <div class="service-name">Technology Support</div>
            <div class="service-desc">Whether it's platform testing prior to your event or assistance on the day of, we'll provide technology support 
                                   to help your event run smoothly.</div>
          </div>

          <div class="service">
            <div class="service-icon">
            <img src="<?php echo e(('images/vitevent.png')); ?>"/>
            </div>
            <div class="service-name">Virtual Event Design</div>
            <div class="service-desc">Our team will plan, 
                                  design and launch your virtual event to 
                                  meet the experiential and technical needs 
                                  of your attendees.</div>
          </div>

          <div class="service">
            <div class="service-icon">
            <img src="<?php echo e(('images/regi.png')); ?>"/>
            </div>
            <div class="service-name">Event Registration</div>
            <div class="service-desc">Easily accept registration and payment in advance, 
                                  making signing up a seamless experience for your attendee</div>
          </div>
           

          <!-- <div class="service">
            <div class="service-icon">
              <i class="fas fa-headset"></i>
            </div> -->
           
        </div>
      </div>
    </section>
</body>
</html><?php /**PATH C:\xampp\htdocs\VirtualHostEvent\resources\views/cartes.blade.php ENDPATH**/ ?>